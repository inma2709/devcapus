import { NavLink, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { initSubmenuPositioning } from "../utils/submenuPositioning";

const linkClass = ({ isActive }) => "topnav-link" + (isActive ? " active" : "");
const subLinkClass = ({ isActive }) => "submenu-link" + (isActive ? " active" : "");


export default function TopNav() {
  const location = useLocation();

  // Inicializar posicionamiento inteligente de submenús (fixed sobre el viewport)
  useEffect(() => {
    const cleanup = initSubmenuPositioning();
    return cleanup;
  }, []);

  // Cerrar submenús cuando cambie la ruta
  useEffect(() => {
    // Cerrar todos los submenús abiertos
    document.querySelectorAll('.topnav-group[open]').forEach(details => {
      details.open = false;
    });
  }, [location.pathname]);

  return (
    <nav className="topnav" aria-label="Navegación principal">
      <div className="topnav-inner">

        {/* INICIO */}
        <NavLink to="/" className={linkClass}>
          <span aria-hidden="true">🏠</span>
          <span className="label">Inicio</span>
        </NavLink>

        <details className="topnav-group">
          <summary className="topnav-link"><span aria-hidden="true">🌱</span><span className="label">Primeros pasos</span></summary>
          <div className="topnav-submenu" role="menu" aria-label="Recorrido esencial">
            <NavLink to="css-introduccion" className={subLinkClass}>Esencial · Qué es CSS</NavLink>
            <NavLink to="css-interno-externo-1" className={subLinkClass}>Esencial · Conectar CSS</NavLink>
            <NavLink to="css-selectores-basicos" className={subLinkClass}>Esencial · Selectores</NavLink>
            <NavLink to="css-texto-1" className={subLinkClass}>Esencial · Texto</NavLink>
            <NavLink to="css-box-model" className={subLinkClass}>Esencial · Modelo de caja</NavLink>
            <NavLink to="css-flexbox-1" className={subLinkClass}>Esencial · Flexbox</NavLink>
            <NavLink to="css-grid-1" className={subLinkClass}>Esencial · Grid</NavLink>
            <NavLink to="css-media-queries" className={subLinkClass}>Esencial · Responsive</NavLink>
          </div>
        </details>

        {/* FUNDAMENTOS */}
        <details className="topnav-group">
          <summary className="topnav-link">
            <span aria-hidden="true">🧱</span>
            <span className="label">Fundamentos</span>
          </summary>

          <div className="topnav-submenu" role="menu" aria-label="Submenú Fundamentos">
            <NavLink to="css-introduccion" className={subLinkClass}>Introducción</NavLink>
            <NavLink to="css-interno-externo-1" className={subLinkClass}>CSS interno / externo</NavLink>
            <NavLink to="css-interno-externo-2" className={subLinkClass}>CSS base (reset general)</NavLink>
            <NavLink to="css-cascada-1" className={subLinkClass}>Cascada y especificidad ⭐</NavLink>
            <NavLink to="css-cascada-2" className={subLinkClass}>Cascada II: práctica</NavLink>
            <NavLink to="css-devtools" className={subLinkClass}>DevTools y depuración</NavLink>
            <NavLink to="css-variables" className={subLinkClass}>Variables CSS</NavLink>
          </div>
        </details>

        {/* SELECTORES */}
        <details className="topnav-group">
          <summary className="topnav-link">
            <span aria-hidden="true">🎯</span>
            <span className="label">Selectores</span>
          </summary>

          <div className="topnav-submenu" role="menu" aria-label="Submenú Selectores">
            <NavLink to="css-selectores-basicos" className={subLinkClass}>Básicos</NavLink>
            <NavLink to="css-selectores-avanzados" className={subLinkClass}>Avanzado · Selectores</NavLink>
            <NavLink to="css-pseudoclases" className={subLinkClass}>Pseudoclases y pseudoelementos</NavLink>
            <NavLink to="css-pseudoclases-funcionales" className={subLinkClass}>Avanzado · Pseudoclases funcionales</NavLink>
            <NavLink to="css-practica-selectores" className={subLinkClass}>Práctica guiada ⭐</NavLink>
          </div>
        </details>
        
          <details className="topnav-group">
          <summary className="topnav-link">
            <span aria-hidden="true">🍀</span>
            <span className="label">Aspectos visuales</span>
          </summary>

          <div className="topnav-submenu" role="menu" aria-label="Submenú Aspectos visuales">
            <NavLink to="css-texto-1" className={subLinkClass}>Texto y tipografía I</NavLink>
            <NavLink to="css-texto-2" className={subLinkClass}>Texto y tipografía II</NavLink>
            <NavLink to="css-tipografia" className={subLinkClass}>Legibilidad ⭐</NavLink>
            <NavLink to="css-fondos" className={subLinkClass}>Fondos y gradientes</NavLink>
            <NavLink to="css-imagenes-1" className={subLinkClass}>Imágenes I</NavLink>
            <NavLink to="css-imagenes-2" className={subLinkClass}>Imágenes II</NavLink>
          </div>
        </details>

        {/* LAYOUT */}
        <details className="topnav-group">
          <summary className="topnav-link">
            <span aria-hidden="true">📐</span>
            <span className="label">Layout</span>
          </summary>

          <div className="topnav-submenu" role="menu" aria-label="Submenú Layout">
            <NavLink to="css-box-model" className={subLinkClass}>Box model</NavLink>
            <NavLink to="css-display" className={subLinkClass}>Display y flujo</NavLink>
            <NavLink to="css-overflow" className={subLinkClass}>Overflow y contención</NavLink>
            <NavLink to="css-overlays" className={subLinkClass}>Position y z-index</NavLink>
            <NavLink to="css-flexbox-1" className={subLinkClass}>Flexbox I ⭐</NavLink>
            <NavLink to="css-flexbox-2" className={subLinkClass}>Flexbox II: alineación</NavLink>
            <NavLink to="css-grid-1" className={subLinkClass}>Grid I ⭐</NavLink>
            <NavLink to="css-grid-2" className={subLinkClass}>Grid II: fracciones</NavLink>
            <NavLink to="css-grid-areas" className={subLinkClass}>Grid Areas ⭐</NavLink>
          </div>
        </details>


        {/* COMPONENTES */}
        <details className="topnav-group">
          <summary className="topnav-link">
            <span aria-hidden="true">🧩</span>
            <span className="label">Componentes</span>
          </summary>

          <div className="topnav-submenu" role="menu" aria-label="Submenú Componentes">
            <NavLink to="css-botones-vinculos" className={subLinkClass}>Botones y vínculos</NavLink>
            <NavLink to="css-navbar" className={subLinkClass}>Navegación</NavLink>
            <NavLink to="css-tablas" className={subLinkClass}>Tablas</NavLink>
            <NavLink to="css-formularios" className={subLinkClass}>Formularios</NavLink>
            <NavLink to="css-modales" className={subLinkClass}>Modales y diálogos</NavLink>
            <NavLink to="css-overlays" className={subLinkClass}>Overlays (tooltips, popovers)</NavLink>
          </div>
        </details>

        {/* RESPONSIVE */}
        <details className="topnav-group">
          <summary className="topnav-link">
            <span aria-hidden="true">📱</span>
            <span className="label">Responsive</span>
          </summary>

          <div className="topnav-submenu" role="menu" aria-label="Submenú Responsive">
            <NavLink to="css-media-queries" className={subLinkClass}>Media queries</NavLink>
            <NavLink to="css-responsive-layout" className={subLinkClass}>Layout responsive</NavLink>
            <NavLink to="css-accesibilidad" className={subLinkClass}>Accesibilidad</NavLink>
          </div>
        </details>

        {/* EXTRA */}
        <details className="topnav-group">
          <summary className="topnav-link">
            <span aria-hidden="true">🚀</span>
            <span className="label">Frameworks</span>
          </summary>

          <div className="topnav-submenu" role="menu" aria-label="Submenú Extra">
            <NavLink to="css-sass" className={subLinkClass}>Avanzado · SASS</NavLink>
            <NavLink to="css-bootstrap" className={subLinkClass}>Ampliación · Bootstrap</NavLink>
            <NavLink to="css-tailwind" className={subLinkClass}>Avanzado · Tailwind CSS</NavLink>
          </div>
        </details>

        {/* EJERCICIOS */}
        <NavLink to="ejercicios" className={linkClass}>
          <span aria-hidden="true">🏋️</span>
          <span className="label">Ejercicios</span>
        </NavLink>

       
      </div>
    </nav>
  );
}
